<?php

return [
    'card_loop'=>[
        'ifPublicUserPage' => 'Share your ideas!',
        'show' => 'Show',
        'edit' => 'Edit',
        'delete' => 'Delete',
        'notHaveThings' => "I guess you don't have an idea yet .."
    ],
    'languageWarning'=>'The page will be refreshed, your data may be lost, do you confirm?',
    'languageSameSelectWarning' => 'It is already set to the language you want to select.',
];