<?php

return [
    'index'=>[
        'serviceProviderProblem' => 'The service provider is not currently running',
        'head_metas' => [
            'default_content_title' => 'Ideas always evolve',
            'default_content_description' => 'and evolving is good :)',
            'default_slogan' => 'Share your ideas!',
        ],
    ],
];