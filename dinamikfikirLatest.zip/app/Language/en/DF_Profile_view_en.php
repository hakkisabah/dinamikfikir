<?php

return [
    'index'=>[
        'avatar' => 'Avatar',
        'userName' => 'User name',
        'firstName' => 'First name',
        'lastName' => 'Last name',
        'mailAddress' => 'Email address',
        'pass' => 'Password',
        'passConfrim' => 'Password confirm',
        'update' => 'Update',
        'selectAvatar' => 'Select avatar',
        'close' => 'Close',
        'save' => 'Save',
        'avatarProblem' => 'Cannot select avatar.'
    ]
];