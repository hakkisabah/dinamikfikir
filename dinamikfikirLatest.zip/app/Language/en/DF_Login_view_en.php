<?php

return [
    'index'=>[
        'pleaseLoginLabel' => 'Please login',
        'login' => 'Login',
        'passPlaceHolder' => 'Password',
        'mailPlaceHolder' => 'Email address',
        'register' => "I don't have an account, I want to register?",
         'forgot' => 'I forgot my password',
    ],
    'forgot'=>[
        'forgotLabel' => 'Enter your e-mail address to reset your password',
        'mailAddress' => 'Email address',
        'renew' => 'Renew',
    ],

];