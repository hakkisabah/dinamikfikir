<?php

return [

    'pageError' => 'Error',
    'pageNotFound' => 'Page not found.',

];