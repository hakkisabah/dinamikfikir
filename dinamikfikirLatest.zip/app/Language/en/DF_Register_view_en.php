<?php

return [
    'index'=>[
        'signUp' => 'Sign Up',
        'register' => 'Register',
        'userNamePlaceHolder' => 'Your username',
        'firstNamePlaceHolder' => 'Your Name',
        'lastNamePlaceHolder' => 'Your Last Name',
        'mailAddress' => 'Your mail address',
        'pass' => 'Your password',
        'passConfrim' => 'Re-enter your password',
        'haveAccount' => 'I have an account',
    ],
];