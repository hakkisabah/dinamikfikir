<?php

return [
    'contents' => [
        'title' => 'My Latest Ideas ..',
        'comments' => 'Comments',
    ],
    'editor' => [
        'titleImageUpload' => 'Upload Title Image',
        'titlePlaceHolder' => 'Enter title',
        'save' => 'Save',
        'navigatorProblem' => 'The browser you are using is not recommended for this website. You may encounter errors .. ',
    ],

];