<?php

return [
    'index'=>[
        'cookieContent' => [
            'message' => 'This web page uses cookies. For more information ',
            'dismiss' => 'OK',
            'linkMessage' => 'click here.',
        ]
    ],
];