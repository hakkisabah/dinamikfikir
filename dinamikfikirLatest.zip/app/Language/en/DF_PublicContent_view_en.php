<?php

return [
    'index'=>[
        'author' => 'Author',
        'edit' => 'Edit',
        'writeComment' => 'Comment',
        'deleteComment'=>'Delete',
        'comments' => 'Comments',
        'notHaveComment' => 'There are no comments yet',
        'writeToComment' => 'Write a comment',
        'loginForComment' => 'Login to comment',
    ]
];