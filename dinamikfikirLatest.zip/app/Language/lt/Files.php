<?php
/**
 * Files language strings.
 *
 * @package    CodeIgniter
 * @author     CodeIgniter Dev Team
 * @copyright  2019 CodeIgniter Foundation
 * @license    https://opensource.org/licenses/MIT	MIT License
 * @link       https://codeigniter.com
 * @since      Version 4.0.0
 * @filesource
 *
 * @codeCoverageIgnore
 */

return [
   'fileNotFound' => 'Failo rasti nepavyko: {0}',
   'cannotMove'   => 'Nepavyko perkelti failo {0} į {1} ({2})',
];
