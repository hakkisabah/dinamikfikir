<?php

return [
    'index'=>[
        'cookieContent'=>[
            'message'=>'Bu web sayfası çerezleri kullanmaktadır. Daha fazla bilgi için ',
            'dismiss'=>'Tamam',
            'linkMessage'=>'buraya tıklayınız.',
        ]
    ],
];