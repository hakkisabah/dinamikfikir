<?php

return [
    'contents'=>[
        'title'=>'Son Fikirlerim..',
        'comments'=>'Yorumlar',
    ],
    'editor'=>[
        'titleImageUpload'=>'Başlık Resmi Yükle',
        'titlePlaceHolder'=>'Başlık giriniz',
        'save'=>'Kaydet',
        'navigatorProblem'=>'Kullanmış olduğunuz tarayıcı bu websayfası için önerilmemektedir. Hatalar ile karşılaşabilirsiniz..',
    ],

];