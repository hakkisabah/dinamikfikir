<?php

return [
    'index'=>[
        'pleaseLoginLabel'=>'Lütfen giriş yapınız',
        'login'=>'Giriş yap',
        'passPlaceHolder'=>'Şifre',
        'mailPlaceHolder'=>'Email adresi',
        'register'=>'Hesabım yok kayıt istiyorum?',
        'forgot'=>'Şifremi unuttum',
    ],
    'forgot'=>[
        'forgotLabel'=>'Şifrenizi yenilemek için mail adresinizi giriniz',
        'mailAddress'=>'Email adresi',
        'renew'=>'Yenile',
    ],

];