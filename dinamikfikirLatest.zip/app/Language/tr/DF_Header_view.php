<?php

return [
    'index'=>[
        'serviceProviderProblem'=>'Hizmet sağlayıcı şu anda çalışmıyor',
        'head_metas'=>[
          'default_content_title' =>'Fikirler her zaman gelişir',
          'default_content_description' =>' ve gelişim iyidir :)',
          'default_slogan' =>'Fikirlerinizi paylaşın !',
        ],
    ],
];