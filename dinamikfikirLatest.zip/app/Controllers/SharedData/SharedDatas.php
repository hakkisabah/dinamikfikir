<?php


namespace App\Controllers\SharedData;


interface SharedDatas
{
    public function getIndexData();
}